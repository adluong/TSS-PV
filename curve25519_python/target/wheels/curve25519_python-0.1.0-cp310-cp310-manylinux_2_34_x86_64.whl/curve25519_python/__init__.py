from .curve25519_python import *

__doc__ = curve25519_python.__doc__
if hasattr(curve25519_python, "__all__"):
    __all__ = curve25519_python.__all__